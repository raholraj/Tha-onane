# PreviewScreen.kt — Changes Required

All changes are inside the existing `ContentScreen` composable and the `LayoutWrapper`
function. No new top-level functions are needed.

---

## 1 · Add imports (at the top of the file)

```kotlin
import com.google.jetpackcamera.model.ConcurrentCameraMode
import com.google.jetpackcamera.model.DualRecordingMode
import com.google.jetpackcamera.ui.components.capture.DualCameraButton
import com.google.jetpackcamera.ui.components.capture.DualCameraModePicker
import com.google.jetpackcamera.ui.components.capture.DraggablePipOverlay
import com.google.jetpackcamera.ui.controller.DualCameraController
```

---

## 2 · Add `dualCameraController` param to `ContentScreen`

```kotlin
private fun ContentScreen(
    ...
    zoomController: ZoomController? = null,
    dualCameraController: DualCameraController? = null   // ← ADD
) {
```

---

## 3 · Add state derivation inside `ContentScreen` (after the existing `remember` blocks)

```kotlin
// ── Dual-camera state ─────────────────────────────────────────────────────
val dualRecordingMode by remember {
    derivedStateOf {
        (currentCaptureUiStateProvider().quickSettingsUiState
            as? QuickSettingsUiState.Available)
            ?.let {
                // Read from cameraAppSettings passed through UiState adapter.
                // For now we surface via a separate derivation; see step 4.
                null
            } ?: DualRecordingMode.PIP  // safe default
    }
}

// Whether the concurrent (dual) camera is currently active.
// We check the captureModeToggle state which is already derived from settings.
val isDualCamActive = remember {
    derivedStateOf {
        (currentCaptureUiStateProvider().captureModeToggleUiState
            as? CaptureModeToggleUiState.Enabled)
            ?.captureMode == CaptureMode.VIDEO_ONLY &&
        currentCaptureUiStateProvider().flipLensUiState is FlipLensUiState.Unavailable
    }
}

var showDualCameraModePicker by remember { mutableStateOf(false) }
```

> **Simpler alternative:** expose `dualRecordingMode` directly on `CaptureUiState.Ready`
> (add it to the data class and wire it up in the `captureUiState()` flow builder, reading
> from `CameraSystem.getCurrentSettings()`). That is the architecturally cleanest path and
> avoids the workaround above.

---

## 4 · Build the dual-camera button lambda (alongside the other lambdas)

```kotlin
val dualCameraButtonLambda = remember(
    isDualCamActive,
    dualRecordingMode,
    videoRecordingState,
    dualCameraController
) {
    @Composable { modifier: Modifier ->
        if (isDualCamActive.value) {
            DualCameraButton(
                currentMode = dualRecordingMode.value,
                // Disable during recording so mode changes take effect on the next recording.
                enabled = videoRecordingState.value !is VideoRecordingState.Active,
                onClick = { showDualCameraModePicker = true },
                modifier = modifier
            )
        }
    }
}
```

---

## 5 · Build the PIP overlay lambda

```kotlin
val pipOverlayLambda = remember(isDualCamActive, dualRecordingMode) {
    @Composable { _: Modifier ->
        DraggablePipOverlay(
            visible = isDualCamActive.value &&
                dualRecordingMode.value == DualRecordingMode.PIP
        )
    }
}
```

---

## 6 · Show the mode-picker dialog (inside `ContentScreen`, before `LayoutWrapper`)

```kotlin
if (showDualCameraModePicker) {
    DualCameraModePicker(
        currentMode = dualRecordingMode.value,
        onModeSelected = { mode ->
            dualCameraController?.setDualRecordingMode(mode)
        },
        onDismiss = { showDualCameraModePicker = false }
    )
}
```

---

## 7 · Pass new lambdas to `LayoutWrapper`

```kotlin
LayoutWrapper(
    ...
    dualCameraButton = dualCameraButtonLambda,   // ← ADD
    pipOverlay = pipOverlayLambda                // ← ADD
)
```

---

## 8 · Add params to `LayoutWrapper`

```kotlin
private fun LayoutWrapper(
    ...
    dualCameraButton: @Composable (Modifier) -> Unit = {},   // ← ADD
    pipOverlay: @Composable (Modifier) -> Unit = {}          // ← ADD
) {
    PreviewLayout(
        ...
        dualCameraButton = dualCameraButton,   // ← ADD
        pipOverlay = pipOverlay                // ← ADD
    )
}
```

---

## 9 · Wire `dualCameraController` in `PreviewViewModel`

In `PreviewViewModel.kt`, add:

```kotlin
val dualCameraController: DualCameraController = DualCameraControllerImpl(
    cameraSystem = cameraSystemRepository.cameraSystem,
    coroutineContext = viewModelScope.coroutineContext
)
```

And pass it through in `PreviewScreen`:

```kotlin
ContentScreen(
    ...
    dualCameraController = viewModel.dualCameraController   // ← ADD
)
```
