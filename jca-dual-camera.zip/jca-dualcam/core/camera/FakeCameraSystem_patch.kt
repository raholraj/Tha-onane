// FILE: core/camera/testing/src/main/java/com/google/jetpackcamera/core/camera/testing/FakeCameraSystem.kt
//
// ADD this override directly after setConcurrentCameraMode:

    override suspend fun setDualRecordingMode(mode: com.google.jetpackcamera.model.DualRecordingMode) {
        currentSettings.update { old ->
            old.copy(dualRecordingMode = mode)
        }
    }
