// FILE: core/camera/src/main/java/com/google/jetpackcamera/core/camera/CameraSession.kt
// REQUIRED CHANGES: Change visibility of two functions from `private` to `internal`
// so that ConcurrentCameraSession.kt (a different file in the same module) can call them.
//
// CHANGE 1 — around line ~1030 in CameraSession.kt (the `getPendingRecording` function):
//   BEFORE: private fun getPendingRecording(
//   AFTER:  internal fun getPendingRecording(
//
// CHANGE 2 — around line ~1120 in CameraSession.kt (the `startVideoRecordingInternal` function):
//   BEFORE: private suspend fun startVideoRecordingInternal(
//   AFTER:  internal suspend fun startVideoRecordingInternal(
//
// WHY: Kotlin `private` is file-scoped. ConcurrentCameraSession.kt calls both functions
// from a different file inside the same Gradle module, which requires at least `internal`.
// No other code changes are needed in CameraSession.kt.
//
// NOTE: This file is intentionally NOT a drop-in replacement. Follow the two edits above
// in your checked-out copy of JCA's CameraSession.kt.
