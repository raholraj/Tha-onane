// FILE: core/settings/src/main/java/com/google/jetpackcamera/settings/model/CameraAppSettings.kt
//
// ADD the following import at the top of the file (with the other model imports):
//   import com.google.jetpackcamera.model.DualRecordingMode
//
// ADD this field to the CameraAppSettings data class, directly after concurrentCameraMode:
//   val dualRecordingMode: DualRecordingMode = DualRecordingMode.PIP,
//
// Example of how the block looks after the change:
//
//   val concurrentCameraMode: ConcurrentCameraMode = ConcurrentCameraMode.OFF,
//   val dualRecordingMode: DualRecordingMode = DualRecordingMode.PIP,   // ← NEW
//   val maxVideoDurationMillis: Long = UNLIMITED_VIDEO_DURATION,
